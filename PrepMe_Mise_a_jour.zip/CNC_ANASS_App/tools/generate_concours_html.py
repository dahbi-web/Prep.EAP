from pathlib import Path
from html import escape
import json
import re
import unicodedata

import pdfplumber

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT.parent / "concours commun"
DEST = ROOT / "concours-commun"

STYLE = """
:root{color-scheme:light;--ink:#17212b;--muted:#66727e;--line:#dbe3ea;--blue:#1769aa;--bg:#f4f7fa;--paper:#fff}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--ink);font:16px/1.55 system-ui,-apple-system,Segoe UI,sans-serif}
header{position:sticky;top:0;z-index:5;background:rgba(255,255,255,.96);border-bottom:1px solid var(--line);padding:14px clamp(16px,4vw,48px);backdrop-filter:blur(8px)}
.head{max-width:1100px;margin:auto;display:flex;gap:14px;align-items:center;justify-content:space-between}.title{font-weight:800;font-size:clamp(17px,2.5vw,24px);line-height:1.2}.sub{color:var(--muted);font-size:13px;margin-top:3px}
button,input{font:inherit}button{border:1px solid var(--line);background:#fff;border-radius:10px;padding:8px 12px;cursor:pointer;color:var(--ink)}button:hover{border-color:var(--blue);color:var(--blue)}
.tools{max-width:1100px;margin:18px auto 0;padding:0 clamp(16px,4vw,48px);display:flex;gap:8px;flex-wrap:wrap;align-items:center}.tools input{flex:1 1 260px;border:1px solid var(--line);border-radius:10px;padding:10px 12px;background:#fff}
main{max-width:1100px;margin:18px auto 48px;padding:0 clamp(16px,4vw,48px)}.page{background:var(--paper);border:1px solid var(--line);border-radius:14px;margin:14px 0;box-shadow:0 3px 12px rgba(23,33,43,.05);overflow:hidden}.page-head{display:flex;justify-content:space-between;gap:12px;padding:10px 16px;background:#eef4f8;color:var(--muted);font-size:13px;font-weight:700}.text{padding:22px;white-space:pre-wrap;overflow-wrap:anywhere;font-family:ui-sans-serif,system-ui,sans-serif}.empty{color:var(--muted);font-style:italic}.hidden{display:none!important}.count{color:var(--muted);font-size:13px;margin-left:auto}
@media print{header,.tools{display:none}body{background:#fff}.page{break-inside:avoid;box-shadow:none;border:0;border-bottom:1px solid #bbb;border-radius:0}.text{padding:12px}}
"""

def slug(index):
    return f"sujet-{index:02d}.html"

def make_page(pdf_path, index):
    pages = []
    with pdfplumber.open(pdf_path) as pdf:
        for number, page in enumerate(pdf.pages, 1):
            text = page.extract_text(x_tolerance=2, y_tolerance=3) or ""
            pages.append(text.strip())
    title = pdf_path.stem
    pages_json = json.dumps(pages, ensure_ascii=False).replace("</", "<\\/")
    html = '''<!doctype html><html lang="fr"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>__TITLE__ · Concours de santé</title><style>__STYLE__</style></head><body>
<header><div class="head"><div><div class="title">__TITLE__</div><div class="sub">Version HTML interactive · __PAGE_COUNT__ pages</div></div><button onclick="if(location.protocol==='blob:'){window.close()}else{location.href='../#/concours'}">← Retour aux concours</button></div></header>
<div class="tools"><input id="q" type="search" placeholder="Rechercher dans ce sujet…" aria-label="Rechercher dans ce sujet"><button id="prev">Page précédente</button><button id="next">Page suivante</button><span id="count" class="count"></span></div><main id="pages"></main>
<script>const DATA=__PAGES_JSON__;const root=document.getElementById('pages'),q=document.getElementById('q'),count=document.getElementById('count');
function draw(){const term=q.value.trim().toLocaleLowerCase();let visible=0;root.innerHTML=DATA.map((text,i)=>{{const hit=!term||text.toLocaleLowerCase().includes(term);if(hit)visible++;return `<section class="page ${{hit?'':'hidden'}}"><div class="page-head"><span>Page ${{i+1}}</span><span>${{term&&hit?'Correspondance trouvée':''}}</span></div><div class="text">${{text?esc(text):'<span class="empty">Cette page est une image sans texte extractible. Ouvrir le PDF original pour la consulter.</span>'}}</div></section>`}}).join('');count.textContent=(term?visible+' page(s) trouvée(s) · ':'')+DATA.length+' page(s)';}}
function esc(s){{return s.replace(/[&<>"']/g,c=>({{'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}}[c]));}}
q.oninput=draw;document.getElementById('prev').onclick=()=>scrollBy(0,-innerHeight*.8);document.getElementById('next').onclick=()=>scrollBy(0,innerHeight*.8);draw();</script></body></html>'''
    html = html.replace('__TITLE__', escape(title)).replace('__STYLE__', STYLE).replace('__PAGE_COUNT__', str(len(pages))).replace('__PAGES_JSON__', pages_json).replace('{{', '{').replace('}}', '}')
    (DEST / slug(index)).write_text(html, encoding="utf-8")

DEST.mkdir(exist_ok=True)
for i, pdf in enumerate(sorted(SOURCE.glob("*.pdf")), 1):
    make_page(pdf, i)
print(f"generated {len(list(DEST.glob('sujet-*.html')))} HTML viewers")
